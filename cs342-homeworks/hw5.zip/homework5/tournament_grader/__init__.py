# Where should we fetch submissions from?
source_assignment = '05'
# Where do we post the results?
grade_assignment = '05_tournament'
from .tournament import grade
