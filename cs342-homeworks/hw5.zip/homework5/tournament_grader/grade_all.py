
def grade(submissions):
    print(submissions)
